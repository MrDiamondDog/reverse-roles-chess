# Just A Normal Game Of Chess
A perfectly normal game of chess- where you switch sides every 5 moves.

Made with nothing but HTML, CSS, and TypeScript.

No external libraries used except for AI.

# Contributing
I didn't run proper tests for this so there's probably some things wrong. Please contribute!
